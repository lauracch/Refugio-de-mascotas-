from django.contrib import admin
from .models import Product, Order 
from django.contrib.auth.models import Group

admin.site.site_header = 'Administracion Dashboard'

class ProductAdmin(admin.ModelAdmin):
    list_display = ('id','nombre','vacuna','sexo','edad','fecha_rescate','image')
    list_filter = ['vacuna']

class OrderAdmin(admin.ModelAdmin):
    list_display = ('nombre_de_mascota','edad_solicitante','direccion','telefono','razones_para_adoptar')

# Register your models here.
admin.site.register(Product, ProductAdmin)
admin.site.register(Order)
#admin.site.unregister(Group)